<template>
  <div class="container mt-5">
    <h1 class="text-center mb-4">Check Room Availability</h1>

    <form @submit.prevent="checkAvailability">
      <div class="card p-4">
        <div class="mb-3">
          <label for="roomId" class="form-label">Room Id:</label>
          <p class="form-control-static">{{ $route.params.roomId }} </p>
        </div>
        <div class="mb-3">
          <label for="roomsName" class="form-label">Room Name:</label>
          <p class="form-control-static"> {{ $route.params.roomsName }}</p>
        </div>
        <div class="row g-3">
  
          <div class="col-md-6">
            <label for="fromDate" class="form-label">From Date:</label>
            <input v-model="availabilityData.fromDate" type="date" class="form-control" id="fromDate" required>
          </div>

          <div class="col-md-6">
            <label for="toDate" class="form-label">To Date:</label>
            <input v-model="availabilityData.toDate" type="date" class="form-control" id="toDate" required>
          </div>

          <div class="col-12">
            <button type="submit" class="btn btn-primary">check Now</button>
          </div>
        </div>
      </div>
    </form>
  </div>
  
</template>

<script>
import axios from 'axios';

export default {
  name: "Availability",
  data() {
    return {
      availabilityData: {
        
       
       
      
        fromDate: '',
        toDate: ''
      },
    };
  },
  methods: {
    async checkAvailability() {
      const roomId = this.$route.params.roomId;

   
      const fromDate = this.availabilityData.fromDate;
      const toDate = this.availabilityData.toDate;

      try {
        const response = await axios.get(
          `https://boutique-hotel.helmuth-lammer.at/api/v1/room/${roomId}/from/${fromDate}/to/${toDate}`,
       
        );
        console.log('Availability Successful');
        // Handle success, e.g., show a confirmation message or navigate to a thank you page
      } catch (error) {
        console.error('no Availability ', error);
        // Handle error, e.g., display an error message to the user
      }
    },
  },
};
</script>