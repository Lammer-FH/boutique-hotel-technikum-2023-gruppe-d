<template>
  <div className="impressum-page">

    <h1>impressum-page</h1>
    <p>Welcome to our hotel. Here, we aim to provide you with a luxurious experience like no other.</p>
    <p>Our mission is to make your stay unforgettable.</p>
  </div>
</template>

<script>
export default {
  name: "ImpressumPage",
};
</script>

<style scoped>

</style>
