<template>
  <div className="history-page">

    <h1>history-page</h1>
    <p>Welcome to our hotel. Here, we aim to provide you with a luxurious experience like no other.</p>
    <p>Our mission is to make your stay unforgettable.</p>
  </div>
</template>

<script>

export default {
  name: "HistoryPage",
};
</script>

<style scoped>
</style>
