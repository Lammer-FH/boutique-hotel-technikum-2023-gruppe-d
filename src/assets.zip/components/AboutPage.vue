<template>
  <div class="about-page">

    <h1>About Us</h1>
    <p>Welcome to our hotel. Here, we aim to provide you with a luxurious experience like no other.</p>
    <p>Our mission is to make your stay unforgettable.</p>
  </div>
</template>

<script>
export default {
  name: "AboutPage",
};
</script>

<style scoped>
/* Add your styles for the About page here */
.about-page {
  background-color: #fff;
  padding: 20px;
}
</style>
